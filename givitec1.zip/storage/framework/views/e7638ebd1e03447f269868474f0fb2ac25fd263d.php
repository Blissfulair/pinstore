<aside class="widget widget_text">
        <h3 class="widget-title">Recent Posts</h3>
        <div class="textwidget">
          <div class="recent-posts type_1">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="recent-posts-item">
              <div class="recent-posts-thumb">
                <a href="<?php echo e(route('post', ['name'=>$p->title])); ?>">
                  <img width="120" height="90" src="<?php echo e(asset('images/posts/'.$p->featured_image)); ?>" class="attachment-small-thumb wp-post-image" alt="<?php echo e($p->featured_image); ?>">											</a>
              </div>
              <a href="<?php echo e(route('post', ['name'=>$p->title])); ?>"><?php echo e($p->title); ?></a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </aside>

      <aside class="widget widget_meta">
        <h3 class="widget-title">CUSTOM LINKS</h3>
        <ul class="list-group">
          <li class="list-group-item"><a href="<?php echo e(route('trainings')); ?>">Tranings and Certification</a></li>
          <li class="list-group-item"><a href="#">Policy</a></li>
          <li class="list-group-item"><a href="<?php echo e(route('services')); ?>">Services</a></li>
          <li class="list-group-item"><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
        </ul>
      </aside>
<?php /**PATH C:\xampp\htdocs\givitec1\givitec1\resources\views/includes/post-sidebar.blade.php ENDPATH**/ ?>