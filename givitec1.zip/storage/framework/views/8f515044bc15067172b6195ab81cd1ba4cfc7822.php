<?php $__env->startSection('title'); ?>
|| Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form class="form-signin" action="<?php echo e(route('login')); ?>" method="post">
        <?php echo csrf_field(); ?>
    <h2 class="form-signin-heading">login</h2>
    <div class="login-wrap">
        <input type="text" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Email">
        <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password" placeholder="Password">
        <label class="checkbox">
            <input type="checkbox" value="remember-me" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember me
            <span class="pull-right">
                <a data-toggle="modal" href="#myModal"> Forgot Password?</a>

            </span>
        </label>
        <button class="btn btn-lg btn-login btn-block" type="submit">Sign in</button>
        <p>or you can sign in via social network</p>
        <div class="login-social-link">
            <a href="index.html" class="facebook">
                <i class="icon-facebook"></i>
                Facebook
            </a>
            <a href="index.html" class="twitter">
                <i class="icon-twitter"></i>
                Twitter
            </a>
        </div>

    </div>
</form>
<form method="POST" id='reset' action="<?php echo e(route('password.email')); ?>">
    <?php echo csrf_field(); ?>

    <!-- Modal -->
    <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Forgot Password ?</h4>
                </div>
                <div class="modal-body">
                    <p>Enter your e-mail address below to reset your password.</p>
                    <input id="email" type="email" placeholder="Email" autocomplete="off" class="form-control placeholder-no-fix <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required  autofocus>
                </div>
                <div class="modal-footer">
                    <button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
                    <button class="btn btn-success" type="submit">Submit</button>
                </div>
            </div>
        </div>
    </div>
    <!-- modal -->
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\givitec1\givitec1\resources\views/auth/login.blade.php ENDPATH**/ ?>