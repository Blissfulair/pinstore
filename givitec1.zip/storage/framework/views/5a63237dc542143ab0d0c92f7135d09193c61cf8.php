<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\givitec1\givitec1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>