<?php if($errors): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger text-center fade in">
        <button data-dismiss="alert" class="close close-sm" type="button">
            <i class="icon-remove"></i>
        </button>
        <?php echo e($error); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(session('success')): ?>
<div class="alert alert-success text-center fade in">
    <button data-dismiss="alert" class="close close-sm" type="button">
        <i class="icon-remove"></i>
    </button>
    <?php echo e(session('success')); ?>

</div>
<?php elseif(session('error')): ?>
<div class="alert alert-danger text-center fade in">
    <button data-dismiss="alert" class="close close-sm" type="button">
        <i class="icon-remove"></i>
    </button>
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\givitec1\givitec1\resources\views/includes/message.blade.php ENDPATH**/ ?>