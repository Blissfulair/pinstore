[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\xampp\htdocs\givitec1\givitec1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>