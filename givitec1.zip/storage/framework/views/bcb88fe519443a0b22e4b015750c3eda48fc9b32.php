<?php $__env->startSection('title'); ?>
  || Services
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title" style="background-image: url('images/title/bg1.png')">
  <div class="container">
    <h1 class="entry-title"></h1>
    <ol class="breadcrumb">
      <li><a href="#">Home</a></li>
      <li class="active">Our Services</li>
    </ol>
  </div>
</div>

<!-- SERVICES VERTICAL LIST
================================================== -->
<section class="featured-services service-img-list">
  <div class="container">
    <div class="row">
      <?php if($services): ?>
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-4">
            <div class="service-item">
              <img class="img-fluid" src="<?php echo e(asset('images/services/'.$service->featured_image)); ?>" alt="Transport">
              <div class="content">
                <div class="type"><i class="fa fa-<?php echo e($service->icon); ?>"></i></div>
                <h5><?php echo e(strtoupper($service->name)); ?></h5>
                <p><?php echo e($service->content); ?></p>
                <a href="<?php echo e(route('service', ['name'=>$service->name])); ?>" class="btn btn-primary">READ MORE<i class="fa fa-arrow-right"></i></a>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- ADVISORY
================================================== -->
<section class="advisory">
  <div class="container">
    <div class="row">
      <div class="col-md-10">
        <h2>Not sure which solution fits you business needs?</h2>
      </div>
      <div class="col-md-2">
      <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary">CONTACT US<i class="fa fa-map-marker"></i></a>      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\givitec1\givitec1\resources\views/frontend/service.blade.php ENDPATH**/ ?>