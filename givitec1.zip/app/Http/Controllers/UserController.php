<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    // public function admin(){
    //     return view('backend.login');
    // }
    // public function register(Request $request){

    // }
    // public function signin(Request $request){
    //     $this->validate($request,[
    //         'email'=>'required',
    //         'password'=>'required'
    //     ]);
    //         if(Auth::attempt(['email'=>$request['email'], 'password'=>$request['password']])){
    //             return redirect()->route('dashboard');
    //         }else
    //         return redirect()->back()->with('error', 'The credentials entered do not exist');

    //  }
}
